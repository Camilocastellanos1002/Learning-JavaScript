const usuario= {
  piso:{},
  piso3:{},
  piso4:{},
  piso5:{},
};

const dato1=document.getElementById('form');
const dato2=document.getElementById('form');
const dato3=document.getElementById('form');

const canecaGris = document.querySelector('#aprovechables');
const canecaVerde = document.querySelector('#organicos');
const canecaNegra = document.querySelector('#no_aprovechables');

const cant1=document.querySelector('#cantidad1');
const cant2=document.querySelector('#cantidad2');
const cant3=document.querySelector('#cantidad3');

//Seleccionando el piso:
document.getElementById('select_floor').addEventListener('input', function (event) {
  event.preventDefault();
  usuario.piso =  event.target.value;
  localStorage.setItem('piso',usuario.piso)
  console.log(usuario.piso);
})


canecaGris.addEventListener('click',e=>{
  cant1.style.display="block";
  cant2.style.display="none";
  cant3.style.display="none";
  dato1.addEventListener('submit', function(event) {
        event.preventDefault();
        if (usuario.piso == 3) {
          usuario.piso3.caprovechables = document.getElementById('cantidad1').value;
          localStorage.setItem('caprovechablesp3', usuario.piso3.caprovechables);    
        }else if (usuario.piso == 4){
          usuario.piso4.caprovechables = document.getElementById('cantidad1').value;
          localStorage.setItem('caprovechablesp4', usuario.piso4.caprovechables);
        }else{
          usuario.piso5.caprovechables = document.getElementById('cantidad1').value;
          localStorage.setItem('caprovechablesp5', usuario.piso5.caprovechables);

        }
        console.log(usuario);
      });
})

canecaVerde.addEventListener('click',e=>{
  cant1.style.display="none";
  cant2.style.display="block";
  cant3.style.display="none";
  dato2.addEventListener('submit', function(event) {
        event.preventDefault();
        if (usuario.piso == 3){
        usuario.piso3.corganicos = document.getElementById('cantidad2').value;
        localStorage.setItem('corganicosp3', usuario.piso3.corganicos);
        }else if(usuario.piso == 4){
        usuario.piso4.corganicos = document.getElementById('cantidad2').value;
        localStorage.setItem('corganicosp4', usuario.piso4.corganicos);
        }else{
        usuario.piso5.corganicos = document.getElementById('cantidad2').value;
        localStorage.setItem('corganicosp5', usuario.piso5.corganicos);
        }
        console.log(usuario);
      });
})

canecaNegra.addEventListener('click',e=>{
  cant1.style.display="none";
  cant2.style.display="none";
  cant3.style.display="block";
  dato3.addEventListener('submit', function(event) {
        event.preventDefault();
        if (usuario.piso == 3){
        usuario.piso3.noaprovechables = document.getElementById('cantidad3').value;
        localStorage.setItem('noaprovechablesp3', usuario.piso3.noaprovechables);
        }else if (usuario.piso == 4){
        usuario.piso4.noaprovechables = document.getElementById('cantidad3').value;
        localStorage.setItem('noaprovechablesp4', usuario.piso4.noaprovechables);
        }else{
        usuario.piso5.noaprovechables = document.getElementById('cantidad3').value;
        localStorage.setItem('noaprovechablesp5', usuario.piso5);

        }
        console.log(usuario);
      });
})